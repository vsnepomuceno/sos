/** Automatically generated file. DO NOT MODIFY */
package br.ufpe.cin.in0953.sos;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}